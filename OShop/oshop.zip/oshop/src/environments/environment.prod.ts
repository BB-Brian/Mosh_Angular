export const environment = {
  production: true,
  firebase: { 
    apiKey: "AIzaSyD3r_yoSegG1eQk0LxPvTaKHjjEGsbWy1M",
    authDomain: "oshop-86bac.firebaseapp.com",
    databaseURL: "https://oshop-86bac.firebaseio.com",
    projectId: "oshop-86bac",
    storageBucket: "",
    messagingSenderId: "992408896007",
    appId: "1:992408896007:web:a10ac57d5b4f8273"
  }
};